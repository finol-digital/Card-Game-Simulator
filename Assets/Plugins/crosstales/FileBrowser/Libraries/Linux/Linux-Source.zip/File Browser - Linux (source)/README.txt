This README explains how-to create and test a "FileBrowser"-library for Unity under Linux.


# Create library
To create a library for your system, navigate to the extracted source files and enter those commands:

sudo apt-get install build-essentials libgtk-3-dev pkg-config
cmake MakeLists.txt
make

=> The library "libFileBrowser.so" is created. Replace it in your Unity-project.


# Test library
To run the test application, which shows all dialogs, enter those commands:

chmod 777 FileBrowser_EXE
./FileBrowser_EXE
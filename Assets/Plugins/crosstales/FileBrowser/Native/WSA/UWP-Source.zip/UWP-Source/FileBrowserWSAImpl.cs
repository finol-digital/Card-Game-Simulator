﻿using System;
using System.Collections.Generic;
using Windows.Storage;
using Windows.Storage.Pickers;
using Windows.Storage.AccessCache;
using Windows.UI.ViewManagement;

namespace Crosstales.FB
{
    public class FileBrowserWSAImpl
    {
        #region Variables

        private List<string> selection = new List<string>();

        //private static StorageFolder logFolder = ApplicationData.Current.LocalFolder;
        //private static StorageFile logFile;

        #endregion


        #region Properties

        public static bool canOpenMultipleFiles
        {
            get
            {
                return true;
            }
        }

        public static bool canOpenMultipleFolders
        {
            get
            {
                return false;
            }
        }

        /// <summary>
        /// Selected files or folders
        /// </summary>
        /// <returns>Selected files or folders</returns>
        public List<string> Selection
        {
            get
            {
                return selection;
            }
        }

        /// <summary>
        /// Indicates if the FB is currently busy.
        /// </summary>
        /// <returns>True if the FB is currently busy</returns>
        public bool isBusy
        {
            get;
            set;
        }

        /// <summary>
        /// DEBUG mode to on/off
        /// </summary>
        public bool DEBUG
        {
            get;
            set;
        }

        #endregion


        #region Public Methods

        /*
        void OpenFilesAsync(string title, string directory, ExtensionFilter[] extensions, bool multiselect, System.Action<string[]> cb);

        void OpenFoldersAsync(string title, string directory, bool multiselect, System.Action<string[]> cb);

        void SaveFileAsync(string title, string directory, string defaultName, ExtensionFilter[] extensions, System.Action<string> cb);
        */

        public async void OpenFiles(List<Extension> extensions, bool multiselect)
        {
            if (EnsureUnsnapped())
            {
                log("INFO", "OpenFiles...");

                selection.Clear();
                isBusy = true;

                try
                {
                    FileOpenPicker openPicker = new FileOpenPicker();
                    openPicker.ViewMode = PickerViewMode.List;
                    //openPicker.SuggestedStartLocation = PickerLocationId.DocumentsLibrary;
                    //openPicker.SuggestedStartLocation = PickerLocationId.PicturesLibrary;
                    openPicker.SuggestedStartLocation = PickerLocationId.ComputerFolder;

                    foreach (Extension extension in extensions)
                    {
                        foreach (string ext in extension.Extensions)
                        {
                            log("DEBUG", "ext: " + ext);

                            openPicker.FileTypeFilter.Add(ext.StartsWith("*") ? ext : "." + ext);
                        }
                    }
                    //openPicker.FileTypeFilter.Add(".jpg");

                    if (multiselect)
                    {
                        IReadOnlyList<StorageFile> files = await openPicker.PickMultipleFilesAsync();

                        if (files.Count > 0)
                        {
                            foreach (StorageFile file in files)
                            {
                                selection.Add(file.Path);
                            }
                        }
                    }
                    else
                    {
                        StorageFile file = await openPicker.PickSingleFileAsync();

                        if (file != null)
                        {
                            selection.Add(file.Path);
                        }
                    }
                }
                catch (Exception ex)
                {
                    log("ERROR", ex.ToString());
                }

                log("INFO", "OpenFiles end: " + selection.Count);
            }
            else
            {
                log("ERROR", "OpenFiles: could not unsnap!" + selection.Count);
            }

            isBusy = false;
        }

        public async void OpenSingleFolder()
        {
            if (EnsureUnsnapped())
            {
                log("INFO", "OpenSingleFolder...");

                selection.Clear();
                isBusy = true;

                try
                {
                    FolderPicker folderPicker = new FolderPicker();
                    folderPicker.ViewMode = PickerViewMode.List;
                    //folderPicker.SuggestedStartLocation = PickerLocationId.DocumentsLibrary;
                    //folderPicker.SuggestedStartLocation = PickerLocationId.PicturesLibrary;
                    folderPicker.SuggestedStartLocation = PickerLocationId.ComputerFolder;
                    folderPicker.FileTypeFilter.Add("*");

                    StorageFolder folder = await folderPicker.PickSingleFolderAsync();

                    if (folder != null)
                    {
                        selection.Add(folder.Path);
                        StorageApplicationPermissions.FutureAccessList.AddOrReplace("PickedFolderToken", folder);
                    }
                }
                catch (Exception ex)
                {
                    log("ERROR", ex.ToString());
                }

                log("INFO", "OpenSingleFolder end: " + selection.Count);
            }
            else
            {
                log("ERROR", "OpenFiles: could not unsnap!" + selection.Count);
            }

            isBusy = false;
        }

        public async void SaveFile(string defaultName, List<Extension> extensions)
        {
            if (EnsureUnsnapped())
            {
                log("INFO", "SaveFile...");

                selection.Clear();
                isBusy = true;

                try
                {
                    FileSavePicker savePicker = new FileSavePicker();
                    //savePicker.SuggestedStartLocation = PickerLocationId.DocumentsLibrary;
                    //savePicker.SuggestedStartLocation = PickerLocationId.PicturesLibrary;
                    savePicker.SuggestedStartLocation = PickerLocationId.ComputerFolder;

                    foreach (Extension extension in extensions)
                    {
                        List<string> exts = new List<string>();

                        foreach (string ext in extension.Extensions)
                        {
                            log("DEBUG", "ext: " + ext);

                            if (ext.Equals("*"))
                            {
                                exts.Add(".");
                            }
                            else
                            {
                                exts.Add(ext.StartsWith("*") ? ext : "." + ext);
                            }
                        }

                        savePicker.FileTypeChoices.Add(extension.Name, exts);
                    }

                    //savePicker.DefaultFileExtension = ??? //TODO set from defaultName (ending)?
                    savePicker.SuggestedFileName = defaultName;
                    StorageFile file = await savePicker.PickSaveFileAsync();

                    if (file != null)
                    {
                        selection.Add(file.Path);
                    }
                }
                catch (Exception ex)
                {
                    log("ERROR", ex.ToString());
                }

                log("INFO", "SaveFile end: " + selection.Count);
            }
            else
            {
                log("ERROR", "OpenFiles: could not unsnap!" + selection.Count);
            }

            isBusy = false;
        }

        public async void GetDirectories(string path, bool isRecursive = false)
        {
            log("INFO", "GetDirectories...");

            selection.Clear();
            isBusy = true;

            try
            {
                StorageFolder folder = await StorageFolder.GetFolderFromPathAsync(path);

                IReadOnlyList<StorageFolder> folders = await folder.GetFoldersAsync();

                // Recurse sub-directories.
                await getDirectories(folders, isRecursive, false);
            }
            catch (UnauthorizedAccessException)
            {
                log("ERROR", "Access to the path '" + path + "' is denied. Did you add the capability 'broadFileSystemAccess' to the 'package.appxmanifest'?");
            }
            catch (Exception ex)
            {
                log("ERROR", ex.ToString());
            }

            log("INFO", "GetDirectories end: " + selection.Count);

            isBusy = false;
        }

        public async void GetFiles(string path, bool isRecursive = false, params string[] extensions)
        {
            log("INFO", "GetFiles...");

            selection.Clear();
            isBusy = true;

            try
            {
                StorageFolder folder = await StorageFolder.GetFolderFromPathAsync(path);

                IReadOnlyList<StorageFolder> folders = await folder.GetFoldersAsync();

                // Recurse sub-directories.
                await getDirectories(folders, isRecursive, true, extensions);

                // Get the files in this folder.
                IReadOnlyList<StorageFile> files = await folder.GetFilesAsync();

                foreach (StorageFile file in files)
                {
                    if (isValidFile(file, extensions))
                    {
                        log("INFO", "File: " + file.Path);

                        selection.Add(file.Path);
                    }
                }
            }
            catch (UnauthorizedAccessException)
            {
                log("ERROR", "Access to the path '" + path + "' is denied. Did you add the capability 'broadFileSystemAccess' to the 'package.appxmanifest'?");
            }
            catch (Exception ex)
            {
                log("ERROR", ex.ToString());
            }

            log("INFO", "GetFiles end: " + selection.Count);

            isBusy = false;
        }

        private async System.Threading.Tasks.Task getDirectories(IReadOnlyList<StorageFolder> folders, bool isRecursive, bool addFiles, params string[] extensions)
        {
            foreach (StorageFolder folder in folders)
            {
                if (!addFiles)
                {
                    log("INFO", "Folder: " + folder.Path);

                    selection.Add(folder.Path);
                }

                // Recurse this folder to get sub-folder info.
                IReadOnlyList<StorageFolder> subDir = await folder.GetFoldersAsync();

                if (subDir.Count > 0 && isRecursive)
                {
                    await getDirectories(subDir, isRecursive, addFiles, extensions);
                }

                if (addFiles && isRecursive)
                {
                    // Get the files in this folder.
                    IReadOnlyList<StorageFile> files = await folder.GetFilesAsync();

                    foreach (StorageFile file in files)
                    {
                        if (isValidFile(file, extensions))
                        {
                            log("INFO", "File: " + file.Path);

                            selection.Add(file.Path);
                        }
                    }
                }
            }
        }

        private bool isValidFile(StorageFile file, params string[] extensions)
        {
            if (extensions == null || extensions.Length == 0)
            {
                return true;
            }
            else
            {
                foreach (string extension in extensions)
                {
                    if (extension.Equals("*") || extension.Equals("*.*"))
                        return true;
                }

                string filename = file.Path;

                foreach (string extension in extensions)
                {
                    if (filename.EndsWith(extension, StringComparison.OrdinalIgnoreCase))
                        return true;
                }
            }

            return false;
        }

        /*
        void SearchFile(StorageFile file, string searchPattern)
        {
                wprintf(L"\nScanning file '%s'\n", file.Path().c_str());
                hstring text = FileIO::ReadTextAsync(file).get();
                std::string sourceText = to_string(text);
                std::smatch match;
                std::string compositePattern =
                    "(\\S+\\s+){0}\\S*" + to_string(searchPattern) + "\\S*(\\s+\\S+){0}";
                std::regex expression(compositePattern);

                while (std::regex_search(sourceText, match, expression))
                {
                    wprintf(L"%8d %S\n", match.position(), match[0].str().c_str());
                    sourceText = match.suffix().str();
                }
            }
            */

        #endregion


        #region Private Methods

        //private async void log(string type, string text)
        private void log(string type, string text)
        {
            if (DEBUG || type.Equals("Error", StringComparison.OrdinalIgnoreCase))
            {
                /*
                if (logFile == null)
                {
                    logFile = await logFolder.CreateFileAsync("FileBrowserUWP.log", CreationCollisionOption.GenerateUniqueName);
                }

                await FileIO.AppendTextAsync(logFile, type + ": " + text + Environment.NewLine);
                */

                UnityEngine.Debug.Log("FileBrowserWSAImpl - " + type + ": " + text);
            }
        }

        internal bool EnsureUnsnapped()
        {
            // FilePicker APIs will not work if the application is in a snapped state.
            // If an app wants to show a FilePicker while snapped, it must attempt to unsnap first
            bool unsnapped = ((ApplicationView.Value != ApplicationViewState.Snapped) || ApplicationView.TryUnsnap());

            /*
            if (!unsnapped)
            {
                NotifyUser("Cannot unsnap the sample.", NotifyType.StatusMessage);
            }
            */

            return unsnapped;
        }

        #endregion
    }

    public struct Extension
    {
        public string Name;
        public string[] Extensions;

        public Extension(string filterName, params string[] filterExtensions)
        {
            Name = filterName;
            Extensions = filterExtensions;
        }

        public override string ToString()
        {
            System.Text.StringBuilder result = new System.Text.StringBuilder();

            result.Append(GetType().Name);
            result.Append(" {");

            result.Append("Name='");
            result.Append(Name);
            result.Append("', ");

            result.Append("Extensions='");
            result.Append(Extensions.Length);
            result.Append("'");

            result.Append("}");

            return result.ToString();
        }
    }
}
// © 2018-2019 crosstales LLC (https://www.crosstales.com)